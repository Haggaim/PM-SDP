function x = colStack(x);
x = x(:);
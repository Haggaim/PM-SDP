classdef InterleavingType
    % enumeration of satrting point of alternating local minization
    enumeration
        X;
        R;
    end
    
end